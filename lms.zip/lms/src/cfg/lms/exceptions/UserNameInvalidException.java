package cfg.lms.exceptions;

public class UserNameInvalidException extends Exception {
    public UserNameInvalidException(String message) {
        super(message);
    }
}
