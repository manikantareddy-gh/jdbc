package packb;
import packa.ClassA;
public class ClassB extends ClassA {
	public static void main(String[] args) {
		ClassB cls = new ClassB();
		System.out.println(cls.a);
		
	}

}
