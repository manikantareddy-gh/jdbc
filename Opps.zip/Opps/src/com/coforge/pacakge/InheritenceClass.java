package com.coforge.pacakge;

public class InheritenceClass {
	public static void main(String[] args) {
		Child ch = new Child();
		ch.addition(1, 10);
		
	}
}
	
	class Parent{
		public int addition(int a, int b)
		{
			return a+b;
		}
	}
	
	class Child extends Parent{
		
	}

// in java we cannot do multiple inheritance
	//example:
	class GrandParent{
		
	}
	class Father extends GrandParent{
		
	}
//	class Son extends Father extends GrandParent{
//		
//	}
// in java we can use multilevel inheritance
	//example:
class GrandParent1{
		
	}
	class Father1 extends GrandParent1{
		
	}
	class Son1 extends Father1{
		
	}
