package com.coforge.pacakge;

public class Getters_and_Setters {
	public static void main(String[] args) {
		ParentClass p = new ParentClass();
		p.setA(10);
		System.out.println(p.getA());
	}
}

class ParentClass{
	private int a;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a=a;
	}
}
