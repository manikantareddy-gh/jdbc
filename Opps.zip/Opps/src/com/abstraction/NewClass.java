package com.abstraction;

public interface NewClass {
    public  void addition(int a, int b);

    public  void subtraction(int a, int b);


}

class MyNewChildClass implements NewClass {
    
    @Override
    public void addition(int a, int b) {
        System.out.println(a + b);
    }

    @Override
    public void subtraction(int a, int b) {
        System.out.println(a - b);
    }
}
