package com.abstraction;

public abstract class MyClass {
    public abstract void addition(int a, int b);

    public abstract void subtraction(int a, int b);

    public static void main(String[] args) {
        MyChildClass mc = new MyChildClass();
        mc.addition(5, 1);
        mc.subtraction(10, 5);
    }
}

class MyChildClass extends MyClass {
    
    @Override
    public void addition(int a, int b) {
        System.out.println(a + b);
    }

    @Override
    public void subtraction(int a, int b) {
        System.out.println(a - b);
    }
}
