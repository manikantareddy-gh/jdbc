package com.collections;

import java.util.List;

public class CollectionDemo1 {
	public static void main(String[] args) {
		List<String> data = null;
		CollectionDemo1 demo = new CollectionDemo1();
		demo.checkSize(data);
	}

	public void checkSize(List data) {
		System.out.println(data != null ? data.size() : 0);
	}

}
