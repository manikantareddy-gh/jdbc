package com.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class CollectionDemo {
	public static void main(String[] args) {
		
		// ------------> static way of adding in the list <------------
//		List<String> list = new Arrays.asList("manikanta","bhgath","vijay");
		
		
		
		
		List<String> list = new ArrayList();
		list.add("1");
		list.add("3");
		list.add("1");

		// -------------> with out using stream api <------------
//		List<String> list2 = new ArrayList();
//		for (int i=0;i<list.size();i++) {
//			list2.add(list.get(i).toUpperCase());
//		}
//		
//		for(int i=0;i<list2.size();i++)
//		{
//			System.out.println(list2.get(i));
//		}

		// ---------------> using stream api <-------------
		List<String> newData = list.stream().map(e -> e.toUpperCase()).collect(Collectors.toList());
		List<String> filterData = list.stream().filter(e -> e.contains("1")).collect(Collectors.toList());
		List<String> UniqueData = list.stream().distinct().collect(Collectors.toList());

		newData.forEach(System.out::println);
		System.out.println("---- filter option ----");
		filterData.forEach(System.out::println);
		System.out.println("-----for distinct option-----");
		UniqueData.forEach(System.out::println);

		System.out.println("---------------> by using set <---------------");
		// ------- by using set ----- as set main priority is an to store distinct
		// values
		Set<String> UniqueSet = list.stream().collect(Collectors.toSet());
		UniqueSet.forEach(System.out::println);
		
		System.out.println("------------> count of the data <--------------");
		// to know the count of the data
		System.out.println(list.stream().count());

	}
}
